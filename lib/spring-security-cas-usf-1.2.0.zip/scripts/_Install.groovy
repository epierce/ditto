println '''
************************************************************
* You've installed the Spring Security CAS (USF) plugin.   *
*                                                          *
* Next run the "usf-cas-config" script to add the default  *
* values to your configuration.                            *
*                                                          *
************************************************************
'''
